function MSE = MSE_variance(lambda, beta,D, t, dt,alpha,eta)

%teoric variance
sigma2 = @(lambda,beta) 2*lambda.*(beta.^2).*dt;
e = @(t,lambda,beta) (exp(-alpha.*t) - exp(-alpha.*(t-dt))...
    - eta*dt);
MSE = 0;
for j = 1:size(D,2)
    cont = 0;
    local_ss = 0;
    for i = 1:size(D,1)
        if(~isnan(D(i,j)))
           local_ss = local_ss + (D(i,j)-e(t(j),lambda,beta)).^2;
           cont = cont+1;
        if (i == size(D,1))
            MSE = MSE + (local_ss./cont - sigma2(lambda, beta)).^2;
        end
    end
end
end


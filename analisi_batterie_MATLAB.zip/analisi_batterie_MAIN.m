%% Analisi batterie

%% Caricamento dataset

X = readmatrix('batteries.xlsx');

X = X(2:end,:);

%difference matrix
% d_ij = D(i,j);

D = diff(X,1,2);

%% Parameters
%time vector
% dt = time interval = 1 month = 1/12

dt = 1/12;

t = [1/12:1/12:32/12];

k = 0.8;

%% find the minimum (alpha_M, eta_M)

M_est = fmincon(@(p) M_fun(p(1),p(2),D,k,t,dt), [0.5;0.5], [-1 0;0 -1],[0;0]);

alpha_M = M_est(1);
eta_M = M_est(2);

%% find beta_M, lambda_M

%nonlinear constrain: lambda*beta-eta=0
nlf = @(p) mycon(p(1),p(2), eta_M);
sol = fmincon(@(p) MSE_variance(p(1), p(2),D, t, dt, alpha_M,eta_M), [1; 1],[],[],[],[],[0;0],[+Inf;+Inf],nlf);
lambda_M = sol(1);
beta_M = sol(2);

%% results
%lambda = 1.09 %beta = 0.0094 %alpha = 0.0071

%per una maggiore interpretabilità dei risultati
%scegliamo lambda = 1 e beta = 0.0103.

lambda = 1; beta = eta_M; alpha = alpha_M;


%% mean time of activity of a battery
% S è la soglia sotto la quale la batteria è da sostituire 
%in genere 80%

S = 0.8;

%orizzonte massimo temporale)
T = 25;
% tau = inf {t in [0,T] : X_t < S} è una variabile aleatoria
% di cui però non sappiamo la legge
% soluzione: simuliamo con MonteCarlo

NSim = 1e5;
dt = 1/12;
t = [0:1/12:T];

% A = matrice delle simulazioni (NSim x length(t))

A = ones(NSim,length(t))*S;
A(:,1) = ones(NSim,1);

%vettore tempi di uscita
exit_times = zeros(NSim,1);

for i=1:NSim
    
    %estraggo il numero di salti
    N_i = poissrnd(lambda*T,1);
    %estraggo i tempi dei salti
    jump_times_i = T*sort(rand(N_i,1));
    
    idx = 1;
    
    flag = 0;
    for j = 2:length(t)
        if (flag==0)
        %deterministic part
        A(i,j) = A(i,j-1) + (exp(-alpha*t(j))-exp(-alpha*t(j-1)));
        
        %se supero un tempo di salto, allora faccio il salto
        while (idx~=(N_i+1) && t(j)>jump_times_i(idx))
            idx = idx+1;
            A(i,j) = A(i,j) - exprnd(beta);
        end
        if(A(i,j) < S)
            exit_times(i) = t(j);
            flag = 1;
        end
        else
            A(i,j)=A(i,j-1);
        end
    end
end

%%
figure;
plot(t,A(1:10,:))
hold on;
line([0,25],[S S]);
title('Simulation of 10 batteries')
ylabel('Percentage')
xlabel('Time (years)')
ylim([0 1])
figure;
histogram(exit_times, 36);
title('Histogram of 100k lifetimes')

vita_media = mean(exit_times);

% 0.9 confidence interval

a = 0.9;
li = round(NSim*((1-a)/2)+1);
ui = NSim*(1-(1-a)/2);
sorted_times = sort(exit_times);

ll = sorted_times(li);
ul = sorted_times(ui);

CI = [ll, vita_media, ul];
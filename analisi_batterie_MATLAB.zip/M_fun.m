function y = M_fun(alpha, eta, D, k, t, dt)

%define mu_t = E[D_t]
% mu depends on time, alpha and eta
mu = @(t,alpha, eta) (exp(-alpha.*t) - exp(-alpha.*(t-dt))...
    - dt*eta);

%define rho
rho = @(x,k) (0.5*x.^2)*(abs(x)<=k) + (k*abs(x) - 0.5*(k^2))*(abs(x)>k);

y = 0;
for i= 1:size(D,1)
    
    %for each sample i, N_i is the number of time istances dt
    % for which I have the data (e.g. 1y8m -> N_i = 20)
    N_i = sum(~isnan(D(i,:)));
    
    for j=1:N_i
        
        %notice that y depends only on alpha and eta
        y = y + rho(D(i,j) - mu(t(j),alpha,eta), k);
    end
end
end


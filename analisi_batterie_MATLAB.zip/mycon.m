function [c,ceq] = mycon(lambda,beta, eta)
         c = [];
         ceq = lambda*beta - eta;
end

